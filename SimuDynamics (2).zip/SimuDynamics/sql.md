CREATE TABLE employee_master (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    email_id VARCHAR(255),
    f_name VARCHAR(100),
    l_name VARCHAR(100)
);
ALTER TABLE employee_master
ADD COLUMN role VARCHAR(50) DEFAULT 'USER',
ADD COLUMN is_active TINYINT(1) DEFAULT 1,
ADD COLUMN is_locked TINYINT(1) DEFAULT 0,
ADD COLUMN login_attempts INT DEFAULT 0,
ADD COLUMN last_login_at DATETIME NULL;

-----------------------------------------------------------------------------------------------
CREATE TABLE autosar_requirements (
    requirement_id        BIGINT PRIMARY KEY AUTO_INCREMENT,

    requirement_code      VARCHAR(50) NOT NULL UNIQUE,
    title                 VARCHAR(255) NOT NULL,
    description           VARCHAR(500) NOT NULL,

    requirement_level     VARCHAR(50) NOT NULL,  -- SYSTEM / SOFTWARE / SAFETY / CALIBRATION
    requirement_type      VARCHAR(50),           -- Functional / Non-Functional / Performance / Safety
    asil_level            VARCHAR(10),           -- QM / ASIL-A / ASIL-B / ASIL-C / ASIL-D
    autosar_module        VARCHAR(50),           -- DCM / DEM / COM / RTE / BSW / SWC
    standard_reference    VARCHAR(100),          -- ISO 26262 / ISO 14229 / AUTOSAR 4.x

    trigger_condition     VARCHAR(500),
    pre_conditions        VARCHAR(500),
    post_conditions       VARCHAR(500),
    error_handling        VARCHAR(500),

    priority              VARCHAR(20),           -- High / Medium / Low
    status                VARCHAR(30),           -- Draft / Approved / Implemented / Verified / Released
    verification_method   VARCHAR(100),          -- MIL / SIL / HIL / Unit Test
    source                VARCHAR(100),          -- OEM / Regulation / Internal
    version               VARCHAR(20) DEFAULT '1.0',

    -- Audit Fields
    created_by            VARCHAR(100) NOT NULL,
    created_date          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by            VARCHAR(100),
    updated_date          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_by            VARCHAR(100),
    deleted_date          TIMESTAMP,
    is_deleted            TINYINT(1) DEFAULT 0
);
-----------------------------------------------------------------------------------------------