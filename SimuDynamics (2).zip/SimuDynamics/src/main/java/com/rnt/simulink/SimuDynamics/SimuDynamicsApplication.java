package com.rnt.simulink.SimuDynamics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimuDynamicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimuDynamicsApplication.class, args);
	}

}
