package com.rnt.simulink.SimuDynamics.apis;

import java.time.Instant;
import java.util.EnumMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rnt.simulink.SimuDynamics.constants.ApiPaths;
import com.rnt.simulink.SimuDynamics.dtos.Credentials;
import com.rnt.simulink.SimuDynamics.dtos.EmployeeMasterDto;
import com.rnt.simulink.SimuDynamics.enums.ResponseKey;
import com.rnt.simulink.SimuDynamics.mapper.EmployeeMapper;
import com.rnt.simulink.SimuDynamics.service.EmployeeService;

@RestController
@RequestMapping(ApiPaths.EMPLOYEE_BASE)
public class EmployeeApis {

	private final EmployeeService employeeService;

	public EmployeeApis(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	@GetMapping
	public ResponseEntity<EnumMap<ResponseKey, Object>> getAllEmployee(HttpServletResponse res,
			HttpServletRequest request, @RequestBody Credentials credentials, HttpSession session) throws Exception {
		Instant start = Instant.now();
		EnumMap<ResponseKey, Object> map = new EnumMap<>(ResponseKey.class);
		try {
			map.put(ResponseKey.SUCCESS, true);
			List<EmployeeMasterDto> apply = EmployeeMapper.TO_EMPLOYEE_DTOS.apply(employeeService.getAllEmployee());
			map.put(ResponseKey.DATA, apply);
		} catch (Exception e) {

		}
		return ResponseEntity.ok(map);
	}
	
	@GetMapping("/test")
	public String getMessage() {
		return "Hello";
	}
}
