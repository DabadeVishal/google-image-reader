package com.rnt.simulink.SimuDynamics.apis;

import java.time.Duration;
import java.time.Instant;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rnt.simulink.SimuDynamics.constants.ApiPaths;
import com.rnt.simulink.SimuDynamics.dtos.Credentials;
import com.rnt.simulink.SimuDynamics.dtos.TokenBody;
import com.rnt.simulink.SimuDynamics.exception.CustomeException;
import com.rnt.simulink.SimuDynamics.repos.UserInfoRepo;
import com.rnt.simulink.SimuDynamics.response.TokenResponseBody;
import com.rnt.simulink.SimuDynamics.securityconfig.CustomeUserDetailsService;
import com.rnt.simulink.SimuDynamics.securityconfig.JwtHelper;
import com.rnt.simulink.SimuDynamics.securityconfig.JwtProperties;
import com.rnt.simulink.SimuDynamics.securityconfig.UserDetail;
import com.rnt.simulink.SimuDynamics.util.Sha1Encriptor;

@RestController
@RequestMapping(ApiPaths.AUTH_BASE)
public class LoginController {

	public static HttpServletRequest re;

	private final UserInfoRepo userInfoRepo;
	private final AuthenticationManager authenticationManager;
	private final CustomeUserDetailsService customeUserDetailsService;
	private final JwtHelper jwtUtil;
	private final JwtProperties jwtProperties;

	private final PasswordEncoder passwordEncoder;
	@Autowired
	public LoginController(UserInfoRepo userInfoRepo, AuthenticationManager authenticationManager,
			CustomeUserDetailsService customeUserDetailsService, JwtHelper jwtUtil, JwtProperties jwtProperties,PasswordEncoder passwordEncoder) {
		this.userInfoRepo = userInfoRepo;
		this.authenticationManager = authenticationManager;
		this.customeUserDetailsService = customeUserDetailsService;
		this.jwtUtil = jwtUtil;
		this.jwtProperties = jwtProperties;
		this.passwordEncoder=passwordEncoder;
	}

	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

	@PostMapping("parse")
	public ResponseEntity<?> parseToken(@RequestBody String token, HttpSession session, HttpServletRequest request) {
		return ResponseEntity.ok(jwtProperties); 

	}

	@PostMapping(ApiPaths.TOKEN)
	public ResponseEntity<TokenResponseBody> crateToken(HttpServletResponse res, HttpServletRequest request,
			@RequestBody Credentials credentials, HttpSession session) throws Exception {
		Instant start = Instant.now();
		if (credentials == null) {
			return ResponseEntity.ok(TokenResponseBody.builder().message("Some fields or Empty")
					.httpStatus(HttpStatus.BAD_REQUEST).durationMs(Duration.between(start, Instant.now()).toMillis())
					.success(Boolean.FALSE).build());
		}

		try {
			String hashedPassword = passwordEncoder.encode("vishal");
			 
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(credentials.getUserName(), credentials.getPassword()));
			UserDetail userDetails = this.customeUserDetailsService.loadUserByUsername(credentials.getUserName());
			String accessToken = this.jwtUtil.generateToken(userDetails, request.getRemoteAddr());
			String refreshToken = this.jwtUtil.generateRefreshToken(userDetails, request.getRemoteAddr());

			return ResponseEntity.ok(TokenResponseBody.builder()
					.message("Login successful. Token generated successfully.").httpStatus(HttpStatus.OK)
					.accessToken(accessToken).refreshToken(refreshToken).success(Boolean.TRUE)
					.durationMs(Duration.between(start, Instant.now()).toMillis()).build());
		} catch (Exception e) {
			logger.error(
					"Login failed for " + credentials.toString() + " and for IP address: " + request.getRemoteAddr(),
					e);
	        throw new CustomeException("Invalid username and passord", e, request);
	        
		}
	}

	@PostMapping(ApiPaths.REFRESH)
	public ResponseEntity<TokenResponseBody> genrateNewUsingAccessToken(@RequestBody TokenBody token,
			HttpSession session, HttpServletRequest request) {

		Instant start = Instant.now();
		try {

			String existingRefreshToken = token.getRefreshToken();
			Boolean tokenExpired = jwtUtil.isTokenExpired(existingRefreshToken);
			if (Boolean.FALSE.equals(tokenExpired)) {

				String emailAsAUserName = jwtUtil.extractUsername(existingRefreshToken);
				UserDetail userDetails = this.customeUserDetailsService.loadUserByUsername(emailAsAUserName);

				String accessToken = this.jwtUtil.generateToken(userDetails, request.getRemoteAddr());
				String refreshToken = this.jwtUtil.generateRefreshToken(userDetails, request.getRemoteAddr());

				return ResponseEntity.ok(TokenResponseBody.builder().message("New access token generated successfully")
						.httpStatus(HttpStatus.OK).accessToken(accessToken).refreshToken(refreshToken)
						.success(Boolean.TRUE).durationMs(Duration.between(start, Instant.now()).toMillis()).build());
			} else {
				return ResponseEntity
						.ok(TokenResponseBody.builder().message("Refresh token is expired. Please log in again.")
								.httpStatus(HttpStatus.OK).accessToken(null).refreshToken(null).success(Boolean.TRUE)
								.durationMs(Duration.between(start, Instant.now()).toMillis()).build());
			}
		} catch (Exception e) {
			logger.error("Unexpected error during genrate new access token  for IP address: " + request.getRemoteAddr(),
					e);
		}
		return null;

	}

	@GetMapping("/csrf")
	public CsrfToken getCsrfToken(HttpServletRequest request) {
		return (CsrfToken) request.getAttribute(CsrfToken.class.getName());
	}

}