package com.rnt.simulink.SimuDynamics.constants;

public class ApiPaths  {
	
	 private ApiPaths() {
	    }
	
	// Login 
	 
    public static final String AUTH_BASE = "/api/v1/auth/";
    public static final String TOKEN = "token";
    public static final String REFRESH = "refresh";

    
    // Employee
    public static final String EMPLOYEE_BASE = "/api/v1/employee/";
 
}
