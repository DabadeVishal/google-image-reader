package com.rnt.simulink.SimuDynamics.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeMasterDto {

    private int staffId;
    private String userName;
    private String email;
    private String fName;
    private String lName;
}