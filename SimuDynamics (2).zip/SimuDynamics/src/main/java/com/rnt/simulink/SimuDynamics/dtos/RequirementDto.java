package com.rnt.simulink.SimuDynamics.dtos;


import java.io.Serializable;

import lombok.Data;

@Data
public class RequirementDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long requirementId;

    private String requirementCode;
    private String title;
    private String description;

    private String requirementLevel;
    private String requirementType;
    private String asilLevel;
    private String autosarModule;
    private String standardReference;

    private String triggerCondition;
    private String preConditions;
    private String postConditions;
    private String errorHandling;

    private String priority;
    private String status;
    private String verificationMethod;
    private String source;
    private String version;

//    /* --- Audit Fields (from Auditable) --- */
//    private String createdBy;
//    private String updatedBy;
//    private String deletedBy;
//
//    private String createdDate;
//    private String updatedDate;
//    private String deletedDate;
//
//    private Boolean isDeleted;
//
//    // Getters and Setters
}
