package com.rnt.simulink.SimuDynamics.dtos;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class TokenBody {

	private String accessToken;
	private String refreshToken;
	
}