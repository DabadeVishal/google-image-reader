package com.rnt.simulink.SimuDynamics.entitys;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "employee_master")
public class EmployeeMaster extends Auditable implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2717119476717527358L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "staff_id")
	Integer staffId;

	@Column(name = "user_id", nullable = false, unique = true, length = 100)
    private String userName;

    @Column(name = "password", nullable = false, length = 255)
    private String password;

    @Column(name = "email_id", nullable = false, unique = true, length = 150)
    private String email;

    @Column(name = "f_name", length = 100)
    private String fName;

    @Column(name = "l_name", length = 100)
    private String lName;

	@Column(name = "role", length = 50)
	private String role = "USER";

	@Column(name = "is_active")
	private boolean isActive = false;

	@Column(name = "is_locked")
	private boolean isLocked = true;

	@Column(name = "login_attempts")
	private int loginAttempts = 0;

}
