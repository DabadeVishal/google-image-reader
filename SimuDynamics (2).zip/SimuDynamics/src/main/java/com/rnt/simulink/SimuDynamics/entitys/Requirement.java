package com.rnt.simulink.SimuDynamics.entitys;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "autosar_requirements")
public class Requirement extends Auditable implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 3703530481313701077L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "requirement_id")
    private Long requirementId;

    @Column(name = "requirement_code", nullable = false, unique = true, length = 50)
    private String requirementCode;

    @Column(name = "title", nullable = false, length = 255)
    private String title;

    @Column(name = "description", nullable = false, length = 500)
    private String description;

    @Column(name = "requirement_level", nullable = false, length = 50)
    private String requirementLevel; // SYSTEM / SOFTWARE / SAFETY / CALIBRATION

    @Column(name = "requirement_type", length = 50)
    private String requirementType; // Functional / Non-Functional / Performance / Safety

    @Column(name = "asil_level", length = 10)
    private String asilLevel; // QM / ASIL-A / ASIL-B / ASIL-C / ASIL-D

    @Column(name = "autosar_module", length = 50)
    private String autosarModule; // DCM / DEM / COM / RTE / BSW / SWC

    @Column(name = "standard_reference", length = 100)
    private String standardReference; // ISO 26262 / ISO 14229 / AUTOSAR 4.x

    @Column(name = "trigger_condition", length = 500)
    private String triggerCondition;

    @Column(name = "pre_conditions", length = 500)
    private String preConditions;

    @Column(name = "post_conditions", length = 500)
    private String postConditions;

    @Column(name = "error_handling", length = 500)
    private String errorHandling;

    @Column(name = "priority", length = 20)
    private String priority; // High / Medium / Low

    @Column(name = "status", length = 30)
    private String status; // Draft / Approved / Implemented / Verified / Released

    @Column(name = "verification_method", length = 100)
    private String verificationMethod; // MIL / SIL / HIL / Unit Test

    @Column(name = "source", length = 100)
    private String source; // OEM / Regulation / Internal

    @Column(name = "version", length = 20)
    private String version = "1.0";

}

