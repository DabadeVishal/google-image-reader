package com.rnt.simulink.SimuDynamics.enums;

public enum ResponseKey {

    MESSAGE("message"),
    SUCCESS("success"),
    DATA("data"),
    DURATION_MS("durationMs"),
    STATUS_CODE("statusCode");

    private final String value;

    ResponseKey(String value) {
        this.value = value;
    }

    public String val() {
        return value;
    }
}
