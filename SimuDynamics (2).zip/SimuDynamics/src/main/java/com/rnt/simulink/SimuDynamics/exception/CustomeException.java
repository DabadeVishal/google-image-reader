package com.rnt.simulink.SimuDynamics.exception;


import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomeException extends RuntimeException   implements Serializable {

	private static final long serialVersionUID = 1L;

	HttpServletRequest httpServletRequest;
	public CustomeException(String message, Throwable cause,HttpServletRequest httpServletRequest) {
		super(message, cause);
		this.httpServletRequest=httpServletRequest;
	}
}