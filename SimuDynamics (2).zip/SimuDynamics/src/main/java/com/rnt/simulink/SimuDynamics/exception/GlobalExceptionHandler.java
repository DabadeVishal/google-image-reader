package com.rnt.simulink.SimuDynamics.exception;

import java.time.Duration;
import java.time.Instant;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.rnt.simulink.SimuDynamics.response.ErrorResponse;

@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(CustomeException.class)
	public ResponseEntity<ErrorResponse> handleCustomeException(CustomeException ex) {
		Instant start = Instant.now();

		if (ex.getCause() instanceof BadCredentialsException
				|| ex.getCause() instanceof InternalAuthenticationServiceException) {

			return ResponseEntity.ok(ErrorResponse.builder().message(ex.getMessage()).listOfMessage(null)
					.statusCode(HttpStatus.BAD_REQUEST).trackStrace(ex.toString()).error(ex.getMessage())
					.success(Boolean.FALSE).durationMs(Duration.between(start, Instant.now()).toMillis()).build());

		}
		return null;
	}

	@ExceptionHandler(BadCredentialsException.class)
	public ResponseEntity<ErrorResponse> BadCredentialsException(BadCredentialsException ex) {
		Instant start = Instant.now();

		return ResponseEntity.ok(ErrorResponse.builder().message(ex.getMessage()).listOfMessage(null)
				.statusCode(HttpStatus.BAD_REQUEST).trackStrace(ex.toString()).error(ex.getMessage())
				.success(Boolean.FALSE).durationMs(Duration.between(start, Instant.now()).toMillis()).build());
	}
}
