package com.rnt.simulink.SimuDynamics.mapper;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import com.rnt.simulink.SimuDynamics.dtos.EmployeeMasterDto;
import com.rnt.simulink.SimuDynamics.entitys.EmployeeMaster;
import com.rnt.simulink.SimuDynamics.util.CollectionUtil;
import com.rnt.simulink.SimuDynamics.util.FunctionUtil;

public class EmployeeMapper {

	public EmployeeMapper() {
	}

	public static final Function<EmployeeMaster, Optional<EmployeeMasterDto>> TO_EMPLOYEE_DTO = e -> FunctionUtil
			.evalMapper(e, EmployeeMasterDto.class);

	public static final Function<EmployeeMasterDto, Optional<EmployeeMaster>> TO_EMPLOYEE_MASTER = e -> FunctionUtil
			.evalMapper(e, EmployeeMaster.class);

	public static final Function<List<EmployeeMaster>, List<EmployeeMasterDto>> TO_EMPLOYEE_DTOS = e -> CollectionUtil.newList(
			FunctionUtil.evalMapperCollection(e, EmployeeMasterDto.class));

	public static final Function<List<EmployeeMasterDto>, List<EmployeeMaster>> TO_EMPLOYEE_MASTERS = e -> CollectionUtil.newList(
			FunctionUtil.evalMapperCollection(e, EmployeeMaster.class));

}
