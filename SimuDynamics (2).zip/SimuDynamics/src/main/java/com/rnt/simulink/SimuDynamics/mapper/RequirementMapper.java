package com.rnt.simulink.SimuDynamics.mapper;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import com.rnt.simulink.SimuDynamics.dtos.RequirementDto;
import com.rnt.simulink.SimuDynamics.entitys.Requirement;
import com.rnt.simulink.SimuDynamics.util.CollectionUtil;
import com.rnt.simulink.SimuDynamics.util.FunctionUtil;

public class RequirementMapper {



	public RequirementMapper() {
	}

	public static final Function<Requirement, Optional<RequirementDto>> TO_REQUIREMENT_DTO = e -> FunctionUtil
			.evalMapper(e, RequirementDto.class);

	public static final Function<RequirementDto, Optional<Requirement>> TO_REQUIREMENT = e -> FunctionUtil
			.evalMapper(e, Requirement.class);

	public static final Function<List<Requirement>, List<RequirementDto>> TO_REQUIREMENT_DTOS = e -> CollectionUtil.newList(
			FunctionUtil.evalMapperCollection(e, RequirementDto.class));

	public static final Function<List<RequirementDto>, List<Requirement>> TO_REQUIREMENTS = e -> CollectionUtil.newList(
			FunctionUtil.evalMapperCollection(e, Requirement.class));


	
}
