package com.rnt.simulink.SimuDynamics.projection;

public interface EmployeeMasterProjection {

	Integer getStaffId();
    String getEmail();
    String getPassword();
	
}
