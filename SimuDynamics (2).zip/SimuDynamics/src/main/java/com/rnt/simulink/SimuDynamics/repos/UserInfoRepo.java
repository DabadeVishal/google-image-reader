package com.rnt.simulink.SimuDynamics.repos;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rnt.simulink.SimuDynamics.entitys.EmployeeMaster;
import com.rnt.simulink.SimuDynamics.projection.EmployeeMasterProjection;

public interface UserInfoRepo extends JpaRepository<EmployeeMaster, Long> {

//	Optional<EmployeeMaster> findByEmail(String email);
	Optional<EmployeeMasterProjection> findByEmail(String email);

}
