package com.rnt.simulink.SimuDynamics.securityconfig;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.rnt.simulink.SimuDynamics.apis.LoginController;
import com.rnt.simulink.SimuDynamics.entitys.EmployeeMaster;
import com.rnt.simulink.SimuDynamics.exception.CustomeException;
import com.rnt.simulink.SimuDynamics.projection.EmployeeMasterProjection;
import com.rnt.simulink.SimuDynamics.repos.UserInfoRepo;

 
 

/**
 * @author Vishal Dabade
 *
 */
@Service
public class CustomeUserDetailsService implements UserDetailsService {

	@Autowired
	UserInfoRepo userInfoRepo;

	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

	@Override
	public UserDetail loadUserByUsername(String email) throws UsernameNotFoundException  {
		try {
			EmployeeMasterProjection optionalUser = userInfoRepo.findByEmail(email).orElse(null);
			if (Objects.nonNull(optionalUser))
				return new UserDetail(optionalUser.getEmail(), optionalUser.getPassword(), true, true, true, true,
						maGrantedAuthorities(), optionalUser.getStaffId());
			else
	            throw new UsernameNotFoundException("User not found with email: " + email);
				
		}
		catch (Exception e) {
			logger.error("Error occurred while loading user by email :"+email);
	        throw new CustomeException("Error occurred while loading user by email", e, null);
		}
	}

	private Collection<? extends GrantedAuthority> maGrantedAuthorities() {
		List<String> list = Arrays.asList("User", "Admin");
		return list.stream().map(e -> new SimpleGrantedAuthority(e)).collect(Collectors.toList());

	}
}