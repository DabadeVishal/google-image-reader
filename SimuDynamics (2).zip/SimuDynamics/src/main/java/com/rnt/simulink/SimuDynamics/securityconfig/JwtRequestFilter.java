package com.rnt.simulink.SimuDynamics.securityconfig;

import static org.springframework.security.core.context.SecurityContextHolder.getContext;

import java.io.IOException;
import java.util.Objects;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.multipart.support.MissingServletRequestPartException;

import com.rnt.simulink.SimuDynamics.util.AuthenticationUtil;

import io.jsonwebtoken.ExpiredJwtException;

@Component
public class JwtRequestFilter extends OncePerRequestFilter {

 
	@Autowired
	private JWTAuthenticationEntryPoint authenticationEntryPoint;

	@Autowired
	private JwtHelper jwtUtil;

	@Autowired
	private CustomeUserDetailsService customeUserDetailsService;
	
	public static final String AUTHORIZATION = "Authorization";
	public static final String BEARER = "Bearer";

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		HttpServletRequest wrappedRequest = request;

		try {
			String ip = request.getRemoteAddr();
		 
			if (AuthenticationUtil.ALLOW_URL.test(request.getServletPath())) {
				filterChain.doFilter(wrappedRequest, response);
				return;
			}
			
			String requestTokenHeader = request.getHeader(AUTHORIZATION);
			if (Objects.isNull(requestTokenHeader)) {
				throw new MissingServletRequestPartException("AUTHORIZATION Header is missing");
			}

			if (requestTokenHeader.startsWith(BEARER)) {
				requestTokenHeader = requestTokenHeader.substring(7);
				try {
 				} catch (Exception e) {
					throw new IllegalArgumentException("Access denied due to token mismatch. Please log in again.");
				}

				String userName = jwtUtil.extractUsername(requestTokenHeader);
				String tokenIp = jwtUtil.extractIpAddress(requestTokenHeader);

				if (!request.getRemoteAddr().equals(tokenIp)) {
					throw new IllegalArgumentException("User mismatch detected. Please log in again to continue.");
				}

				UserDetail loadUserByUsername = customeUserDetailsService.loadUserByUsername(userName);
				if (Boolean.TRUE.equals(jwtUtil.validateToken(requestTokenHeader, loadUserByUsername))) {
					UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
							loadUserByUsername, null, loadUserByUsername.getAuthorities());
					usernamePasswordAuthenticationToken.setDetails(loadUserByUsername);
					getContext().setAuthentication(usernamePasswordAuthenticationToken);
				}
			}

			filterChain.doFilter(wrappedRequest, response);

		} catch (ExpiredJwtException e) {
			authenticationEntryPoint.commence(request, response,
					new InsufficientAuthenticationException("Token Expired", e));
		} catch (IllegalArgumentException e) {
			authenticationEntryPoint.commence(request, response, new IllegalArgumentException(e.getMessage(), e));
		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Internal Server Error");
		}
	}
}