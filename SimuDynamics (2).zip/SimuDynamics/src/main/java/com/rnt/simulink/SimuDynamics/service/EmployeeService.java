package com.rnt.simulink.SimuDynamics.service;

import java.util.List;

import com.rnt.simulink.SimuDynamics.entitys.EmployeeMaster;

public interface EmployeeService {

	List<EmployeeMaster> getAllEmployee();

}
