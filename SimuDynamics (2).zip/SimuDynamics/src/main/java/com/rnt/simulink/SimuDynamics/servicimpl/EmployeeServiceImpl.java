package com.rnt.simulink.SimuDynamics.servicimpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.rnt.simulink.SimuDynamics.entitys.EmployeeMaster;
import com.rnt.simulink.SimuDynamics.repos.UserInfoRepo;
import com.rnt.simulink.SimuDynamics.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	private final UserInfoRepo userInfoRepo;

	public EmployeeServiceImpl(UserInfoRepo userInfoRepo) {
		this.userInfoRepo=userInfoRepo;
	}
	
	@Override
	public List<EmployeeMaster> getAllEmployee() {
		// TODO Auto-generated method stub
		return userInfoRepo.findAll();
	}

}
