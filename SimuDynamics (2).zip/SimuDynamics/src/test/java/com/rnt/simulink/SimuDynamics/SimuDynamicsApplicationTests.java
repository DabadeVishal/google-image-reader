package com.rnt.simulink.SimuDynamics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimuDynamicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
